# postman的几个实用功能


poatman 下载地址：https://www.getpostman.com/downloads/ 点击download 下载

示例 postman版本： v7.2.2

##  查看完整的HTTP请求

1.使用postman  点击菜单栏 View 选择 Show Postman Console 如下图

![图片](https://raw.githubusercontent.com/Baidu-AIP/speech-demo/master/rest-api-asr/postman/doc-images/201906251801.png)

此时再测试HTTP请求会在Console里有完整的请求  如下图

![图片](https://raw.githubusercontent.com/Baidu-AIP/speech-demo/master/rest-api-asr/postman/doc-images/201906251802.png)



### 生成其他编程语言代码
当完成请求后点击 Code 按钮 ，选取HTTP，选择想生成的其他编程语言代码

![图片](https://raw.githubusercontent.com/Baidu-AIP/speech-demo/master/rest-api-asr/postman/doc-images/201906251805.png)
![图片](https://raw.githubusercontent.com/Baidu-AIP/speech-demo/master/rest-api-asr/postman/doc-images/201906251806.png)

##  查看耗时
耗时显示 如下图

![图片](https://raw.githubusercontent.com/Baidu-AIP/speech-demo/master/rest-api-asr/postman/doc-images/201906251804.png)

package com.baidu.speech.restapi.common;

/**
 * DEMO自带的Exception
 */
public class DemoException extends Exception {
    public DemoException(String message) {
        super(message);
    }
}
